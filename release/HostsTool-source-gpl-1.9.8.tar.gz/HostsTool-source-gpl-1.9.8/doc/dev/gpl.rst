:orphan:

GNU General Public License
==========================

`Hosts Setup Utility` is designed by `huhamhire-hosts team` and licensed under
the `GNU General Public License, version 3(GPLv3)`. For further information,
please visit our `website <https://hosts.huhamhire.com>`_.

.. include:: ../../LICENSE
    :literal:
